package Aircraft;

public class F16 extends Aircraft {

  public F16(){
    super.baseDmg = 30;
    super.maxAmmo = 8;
    super.type = "F16";

  }

}
