package Aircraft;

public class F35 extends Aircraft {

  public F35(){
    super.baseDmg = 50;
    super.maxAmmo = 12;
    super.type = "F35";
    super.prior= true;

  }

}
